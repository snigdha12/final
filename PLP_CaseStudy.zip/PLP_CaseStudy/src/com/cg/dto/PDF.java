package com.cg.dto;

public class PDF {
	private String location;

	public PDF(String location) {
		super();
		this.location = location;
	}

	public PDF() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
}
