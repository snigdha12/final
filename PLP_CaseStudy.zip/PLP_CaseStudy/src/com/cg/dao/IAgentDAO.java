package com.cg.dao;

import com.cg.dto.AddUserToAgent;
import com.cg.dto.CreateClaim;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;

public interface IAgentDAO {

	public int addAgent(UserRole agentDTO) throws ICRException;

	public int addUserToAgent(AddUserToAgent addDTO) throws ICRException;

	public int createClaim(CreateClaim createClaim) throws ICRException;
}
