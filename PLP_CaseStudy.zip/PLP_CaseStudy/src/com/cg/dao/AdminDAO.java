package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Policy;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;
import com.cg.utiliy.JdbcUtility;

public class AdminDAO implements IAdminDAO {

	static Connection connection = null;

	@Override
	public int addAdmin(UserRole adminDTO) throws ICRException {
		int Error = -1;
		int rows = 0;
		try {

			connection = JdbcUtility.getConnection();
			PreparedStatement ps = connection.prepareStatement(QueryConstants.ADDROLE);
			ps.setString(1, adminDTO.getUserName());
			ps.setString(2, adminDTO.getPassword());
			ps.setString(3, adminDTO.getRoleCode());
			// System.out.println("after ps.setString");
			rows = ps.executeUpdate();

		} catch (ICRException | SQLException e) {
			return Error;
			// throw new ICRException(e.getMessage()+"problem occured in addagent DAO");
		}
		return rows;
	}

	@Override
	public String validate(UserRole userDTO) throws ICRException {
		boolean status = false;
		String roleCode = "";
		try {
			connection = JdbcUtility.getConnection();
			PreparedStatement ps = connection.prepareStatement(QueryConstants.VALIDATE);
			ps.setString(1, userDTO.getUserName());
			ps.setString(2, userDTO.getPassword());

			ResultSet rs = ps.executeQuery();

			if (rs.next())
				roleCode = rs.getString(1);
			System.out.println("AdminDAO :" + roleCode);
		} catch (ICRException | SQLException e) {
			throw new ICRException(e.getMessage() + "Problem Occured in AdminDAO during login");
		}
		return roleCode;
	}

	@Override
	public int addPolicy(Policy policyDTO) throws ICRException {
		int rows = 0;
		//int Error = -1;
		try {

			connection = JdbcUtility.getConnection();
			PreparedStatement ps = null;
			ResultSet rs = null;
			
			ps = connection.prepareStatement(QueryConstants.GETACCOUNTNO);
			ps.setString(1, policyDTO.getUserName());
			System.out.println(policyDTO.getUserName());
			rs = ps.executeQuery();
			System.out.println("In AdminDAO add policy ()"+rs.getRow());
			rs.next();
			int accountNo = rs.getInt("accountno");
			System.out.println("accno:");
			ps = connection.prepareStatement(QueryConstants.ADDPOLICY1);
			ps.setInt(1, policyDTO.getPolicyNo());
			ps.setInt(2, policyDTO.getPremAmount());
			ps.setInt(3, accountNo);
			ps.setString(4, policyDTO.getPolicy());
			rows = ps.executeUpdate();

			System.out.println("after add policy1" + rows);
			ps = connection.prepareStatement(QueryConstants.ADDPOLICY);
			ps.setString(1, policyDTO.getUserName());
			ps.setInt(2, policyDTO.getPolicyNo());
			rows = ps.executeUpdate();

			System.out.println("after add policy" + rows);

		} catch (ICRException | SQLException e) {
			//return Error;
			throw new ICRException(e.getMessage() + "problem occured in addagent DAO");
		}
		return rows;
	}

}
