package com.cg.exception;

public class ICRException extends Exception{

		public ICRException(String Message) {
			super(Message);
		}
}
