package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.AdminDAO;
import com.cg.dao.IAdminDAO;
import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAO;
import com.cg.dto.Policy;
import com.cg.exception.ICRException;

@WebServlet("/addPolicy")
public class AddPolicyServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getSession().getAttribute("username") == null) {
			response.sendRedirect("index.jsp");

		} else {
			if (request.getSession().getAttribute("rolecode").equals("usr")) {
				response.sendRedirect("userHomePage.jsp");
			} else if (request.getSession().getAttribute("rolecode").equals("agnt")) {
				response.sendRedirect("agentHomePage.jsp");
			}
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		try {
			String userName = request.getParameter("username");
			String policy = request.getParameter("policy");

			int premAmount = Integer.parseInt(request.getParameter("premamount"));
			int policyNo = Integer.parseInt(request.getParameter("policyno"));

			RequestDispatcher dispatcher = null;
			out.println("<html><body>");

			Policy policyDTO = new Policy(userName, policy, premAmount, policyNo);
			IAdminDAO user = new AdminDAO();

			int rows = 0;

			rows = user.addPolicy(policyDTO);

			if (rows > 0) {

				response.setHeader("Refresh", "2;url=adminHomePage.jsp");
			} else if (rows == -1)
				response.sendRedirect("AdminError.jsp");
			else
				out.println("not added");
		} catch (Exception e) {
			response.sendRedirect("AdminError.jsp");
			System.out.println(e.getMessage() + " exception in add policy servlet");
		}
	}

}
