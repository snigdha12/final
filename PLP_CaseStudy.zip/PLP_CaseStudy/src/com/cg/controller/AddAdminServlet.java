package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.dao.AdminDAO;
import com.cg.dao.IAdminDAO;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;

@WebServlet("/addAdmin")
public class AddAdminServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getSession().getAttribute("username") == null) {
			response.sendRedirect("index.jsp");

		} else {
			if (request.getSession().getAttribute("rolecode").equals("usr")) {
				response.sendRedirect("userHomePage.jsp");
			} else if (request.getSession().getAttribute("rolecode").equals("agnt")) {
				response.sendRedirect("agentHomePage.jsp");
			}
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		try {
			String userName = request.getParameter("uname");
			String password = request.getParameter("pwd");
			String roleCode = request.getParameter("rolecode");
			out.println("<html><body>");
			UserRole adminDTO = new UserRole(userName, password, roleCode);
			int rows = 0;
			IAdminDAO admin = new AdminDAO();

			rows = admin.addAdmin(adminDTO);
			if (rows > 0) {
				out.println("<h2 style = 'color:white'>Admin succesfully added, please wait while redirecting to homepage</h2>");
				response.setHeader("Refresh", "2;url=vieClaimsAdmin.jsp");
			} else if (rows == -1)
				response.sendRedirect("AdminError.jsp");
			else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Problem while adding admin, Please try again!');");
				out.println("location='addAdmin.jsp';");
				out.println("</script>");
			}
		} catch (Exception e) {
			response.sendRedirect("AdminError.jsp");
			System.out.println(e.getMessage() + " exception in addAdmin servlet");
		}
		out.println("</html></body>");
	}
}
